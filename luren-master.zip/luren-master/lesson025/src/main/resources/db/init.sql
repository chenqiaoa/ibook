-- 创建账户表
create table if not exists t_user_lesson025
(
    id   int primary key comment '用户id',
    name varchar(50) not null comment '用户名'
) comment '用户表';

-- 向用户表插入50条测试数据
insert ignore into t_user_lesson025 values (1,'路人-1');
insert ignore into t_user_lesson025 values (2,'路人-2');
insert ignore into t_user_lesson025 values (3,'路人-3');
insert ignore into t_user_lesson025 values (4,'路人-4');
insert ignore into t_user_lesson025 values (5,'路人-5');
insert ignore into t_user_lesson025 values (6,'路人-6');
insert ignore into t_user_lesson025 values (7,'路人-7');
insert ignore into t_user_lesson025 values (8,'路人-8');
insert ignore into t_user_lesson025 values (9,'路人-9');
insert ignore into t_user_lesson025 values (10,'路人-10');
insert ignore into t_user_lesson025 values (11,'路人-11');
insert ignore into t_user_lesson025 values (12,'路人-12');
insert ignore into t_user_lesson025 values (13,'路人-13');
insert ignore into t_user_lesson025 values (14,'路人-14');
insert ignore into t_user_lesson025 values (15,'路人-15');
insert ignore into t_user_lesson025 values (16,'路人-16');
insert ignore into t_user_lesson025 values (17,'路人-17');
insert ignore into t_user_lesson025 values (18,'路人-18');
insert ignore into t_user_lesson025 values (19,'路人-19');
insert ignore into t_user_lesson025 values (20,'路人-20');
insert ignore into t_user_lesson025 values (21,'路人-21');
insert ignore into t_user_lesson025 values (22,'路人-22');
insert ignore into t_user_lesson025 values (23,'路人-23');
insert ignore into t_user_lesson025 values (24,'路人-24');
insert ignore into t_user_lesson025 values (25,'路人-25');
insert ignore into t_user_lesson025 values (26,'路人-26');
insert ignore into t_user_lesson025 values (27,'路人-27');
insert ignore into t_user_lesson025 values (28,'路人-28');
insert ignore into t_user_lesson025 values (29,'路人-29');
insert ignore into t_user_lesson025 values (30,'路人-30');
insert ignore into t_user_lesson025 values (31,'路人-31');
insert ignore into t_user_lesson025 values (32,'路人-32');
insert ignore into t_user_lesson025 values (33,'路人-33');
insert ignore into t_user_lesson025 values (34,'路人-34');
insert ignore into t_user_lesson025 values (35,'路人-35');
insert ignore into t_user_lesson025 values (36,'路人-36');
insert ignore into t_user_lesson025 values (37,'路人-37');
insert ignore into t_user_lesson025 values (38,'路人-38');
insert ignore into t_user_lesson025 values (39,'路人-39');
insert ignore into t_user_lesson025 values (40,'路人-40');
insert ignore into t_user_lesson025 values (41,'路人-41');
insert ignore into t_user_lesson025 values (42,'路人-42');
insert ignore into t_user_lesson025 values (43,'路人-43');
insert ignore into t_user_lesson025 values (44,'路人-44');
insert ignore into t_user_lesson025 values (45,'路人-45');
insert ignore into t_user_lesson025 values (46,'路人-46');
insert ignore into t_user_lesson025 values (47,'路人-47');
insert ignore into t_user_lesson025 values (48,'路人-48');
insert ignore into t_user_lesson025 values (49,'路人-49');
insert ignore into t_user_lesson025 values (50,'路人-50');