package com.itsoku.lesson023.common;

/**
 * <b>description</b>： Java高并发、微服务、性能优化实战案例100讲，视频号：程序员路人，源码 & 文档 & 技术支持，请加个人微信号：itsoku <br>
 * <b>time</b>：2024/4/17 10:17 <br>
 * <b>author</b>：ready likun_557@163.com
 */
public class ErrorCode {
    public static final String SERVER_ERROR = "500";
}
