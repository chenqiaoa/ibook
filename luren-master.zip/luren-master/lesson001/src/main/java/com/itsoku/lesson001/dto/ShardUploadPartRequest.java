package com.itsoku.lesson001.dto;

import lombok.Data;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.multipart.MultipartFile;

/**
 * <b>description</b>： Java高并发、微服务、性能优化实战案例100讲，视频号：程序员路人，源码 & 文档 & 技术支持，请加个人微信号：itsoku <br>
 * <b>time</b>：2024/3/26 22:12 <br>
 * <b>author</b>：ready likun_557@163.com
 */
@Data
public class ShardUploadPartRequest {
    /**
     * 分片上传任务id（由初始化分片接口返回的）
     */
    private String shardUploadId;
    /**
     * 第几个分片
     */
    private Integer partOrder;

    /**
     * 分片文件
     */
    private MultipartFile file;
}
