package com.itsoku.lesson004.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.itsoku.lesson004.po.GoodsPO;

/**
 * <b>description</b>： Java高并发、微服务、性能优化实战案例100讲，视频号：程序员路人，源码 & 文档 & 技术支持，请加个人微信号：itsoku <br>
 * <b>time</b>： 21:03 <br>
 * <b>author</b>：ready likun_557@163.com
 */
public interface GoodsService extends IService<GoodsPO> {

    /**
     * 1、第一种解决超卖的方法：update t_goods set num = num - #{购买的商品数量} where goods_id = #{商品id} and num - #{购买的商品数量} >= 0
     */
    void placeOrder1() throws InterruptedException;

    /**
     * 2、第2种方式解决超卖，使用递增的版本解决，也就是大家常说的乐观锁
     *
     * @throws InterruptedException
     */
    void placeOrder2() throws InterruptedException;

    /**
     * 3、第3种方式解决超卖，使用通用的辅助表解决
     *
     * @throws InterruptedException
     */
    void placeOrder3() throws InterruptedException;

    /**
     * 4、第4种方式解决超卖，使用通用的辅助表解决
     *
     * @throws InterruptedException
     */
    void placeOrder4() throws InterruptedException;
}
